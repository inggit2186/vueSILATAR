const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(',') : ["http://localhost:3000", "http://localhost:5173"], // Allow production domain via env var
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

// Store messages in memory (in production, use database)
let messages = [];
let connectedUsers = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Send existing messages to new user
  socket.emit('load_messages', messages);

  // Handle user join
  socket.on('join_chat', (userData) => {
    connectedUsers.set(socket.id, userData);
    socket.broadcast.emit('user_joined', userData);
    // Send messages when user joins chat
    socket.emit('load_messages', messages);
  });

  // Handle new message
  socket.on('send_message', (messageData) => {
    const message = {
      id: Date.now(),
      sender: messageData.sender,
      text: messageData.text,
      type: messageData.type || 'text',
      pp: messageData.pp,
      role: messageData.role,
      time: new Date().toISOString()
    };

    messages.push(message);

    // Keep only last 100 messages
    if (messages.length > 100) {
      messages = messages.slice(-100);
    }

    // Broadcast to all clients
    io.emit('new_message', message);
  });

  // Handle typing indicator
  socket.on('typing_start', (userData) => {
    socket.broadcast.emit('user_typing', userData);
  });

  socket.on('typing_stop', (userData) => {
    socket.broadcast.emit('user_stop_typing', userData);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    const userData = connectedUsers.get(socket.id);
    if (userData) {
      connectedUsers.delete(socket.id);
      socket.broadcast.emit('user_left', userData);
    }
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
